from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
from library import Library
from book import Book

app = FastAPI(title="Library API", version="1.0.0")
library = Library("library.json")

class ISBNRequest(BaseModel):
    isbn: str

class BookResponse(BaseModel):
    title: str
    author: str
    isbn: str

@app.get("/books", response_model=List[BookResponse])
def get_books():
    return [b.to_dict() for b in library.list_books()]

@app.post("/books", response_model=BookResponse)
def add_book(request: ISBNRequest):
    if library.find_book(request.isbn):
        raise HTTPException(status_code=400, detail="Bu ISBN zaten mevcut.")
    from services.openlibrary_client import OpenLibraryClient
    info = OpenLibraryClient.fetch_book_info(request.isbn)
    if not info or not info.get("title"):
        raise HTTPException(status_code=404, detail="Kitap bulunamadı.")
    author = info.get("authors") or "Bilinmeyen Yazar"
    book = Book(info["title"], author, request.isbn)
    library.books.append(book)
    library.save_books()
    return book.to_dict()

@app.delete("/books/{isbn}")
def delete_book(isbn: str):
    book = library.find_book(isbn)
    if not book:
        raise HTTPException(status_code=404, detail="Kitap bulunamadı.")
    library.books.remove(book)
    library.save_books()
    return {"message": f"{isbn} silindi."}
