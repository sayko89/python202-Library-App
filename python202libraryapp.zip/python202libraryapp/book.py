from dataclasses import dataclass

@dataclass(frozen=True)
class Book:
    title: str
    author: str
    isbn: str

    def __str__(self) -> str:
        return f"{self.title} by {self.author} (ISBN: {self.isbn})"

    def to_dict(self) -> dict:
        return {"title": self.title, "author": self.author, "isbn": self.isbn}

    @staticmethod
    def from_dict(data: dict) -> "Book":
        return Book(title=data["title"], author=data["author"], isbn=data["isbn"])
