import httpx

class OpenLibraryClient:
    BASE_URL = "https://openlibrary.org"

    @staticmethod
    def fetch_book_info(isbn: str):
        """Return dict {title, authors} or None if not found/failed."""
        url = f"{OpenLibraryClient.BASE_URL}/isbn/{isbn}.json"
        try:
            response = httpx.get(url, timeout=10.0)
            if response.status_code == 404:
                return None
            response.raise_for_status()
            data = response.json()

            title = data.get("title")
            authors = data.get("authors", [])

            # Fetch author names from author keys
            author_names = []
            for author in authors:
                key = author.get("key")
                if not key:
                    continue
                author_url = f"{OpenLibraryClient.BASE_URL}{key}.json"
                try:
                    res = httpx.get(author_url, timeout=5.0)
                    if res.status_code == 200:
                        author_data = res.json()
                        name = author_data.get("name")
                        if name:
                            author_names.append(name)
                except Exception:
                    # Skip author detail errors but continue
                    pass

            return {
                "title": title,
                "authors": ", ".join([a for a in author_names if a]) if author_names else ""
            }
        except httpx.HTTPError:
            return None
        except Exception:
            return None
