import json
import os
from typing import List, Optional
from book import Book
from services.openlibrary_client import OpenLibraryClient

class Library:
    def __init__(self, filename: str = "library.json"):
        self.filename = filename
        self.books: List[Book] = []
        self.load_books()

    def add_book(self, isbn: str) -> Optional[Book]:
        """Add by ISBN using OpenLibrary. Returns Book if added, else None."""
        if self.find_book(isbn):
            print("Bu ISBN zaten mevcut.")
            return None

        info = OpenLibraryClient.fetch_book_info(isbn)
        if not info or not info.get("title"):
            print("Kitap bulunamadı veya API hatası.")
            return None

        author = info.get("authors") or "Bilinmeyen Yazar"
        book = Book(info["title"], author, isbn)
        self.books.append(book)
        self.save_books()
        print(f"Kitap eklendi: {book}")
        return book

    def remove_book(self, isbn: str) -> bool:
        book = self.find_book(isbn)
        if book:
            self.books.remove(book)
            self.save_books()
            print("Kitap silindi.")
            return True
        else:
            print("Kitap bulunamadı.")
            return False

    def list_books(self) -> List[Book]:
        return list(self.books)

    def find_book(self, isbn: str) -> Optional[Book]:
        for book in self.books:
            if book.isbn == isbn:
                return book
        return None

    def load_books(self) -> None:
        if os.path.exists(self.filename):
            try:
                with open(self.filename, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.books = [Book.from_dict(item) for item in data]
            except (json.JSONDecodeError, OSError):
                self.books = []
        else:
            self.books = []

    def save_books(self) -> None:
        with open(self.filename, "w", encoding="utf-8") as f:
            json.dump([b.to_dict() for b in self.books], f, indent=4, ensure_ascii=False)
