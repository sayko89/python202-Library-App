import os
import pytest
from book import Book
from library import Library

TEST_FILE = "test_library.json"

@pytest.fixture
def library():
    if os.path.exists(TEST_FILE):
        os.remove(TEST_FILE)
    lib = Library(TEST_FILE)
    yield lib
    if os.path.exists(TEST_FILE):
        os.remove(TEST_FILE)

def test_add_and_find_book(library):
    # 9780140328721 -> James and the Giant Peach (should resolve via API)
    added = library.add_book("9780140328721")
    assert added is not None
    assert library.find_book("9780140328721") is not None

def test_remove_book(library):
    library.add_book("9780140328721")
    assert library.remove_book("9780140328721") is True
    assert library.find_book("9780140328721") is None
