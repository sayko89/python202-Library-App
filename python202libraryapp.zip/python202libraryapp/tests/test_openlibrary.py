from services.openlibrary_client import OpenLibraryClient

def test_fetch_valid_book():
    result = OpenLibraryClient.fetch_book_info("9780140328721")
    assert result is not None
    assert "title" in result
    assert result["title"]

def test_fetch_invalid_book():
    result = OpenLibraryClient.fetch_book_info("0000000000000")
    # Should be None for not found/invalid
    assert result is None
