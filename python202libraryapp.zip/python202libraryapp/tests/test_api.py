from fastapi.testclient import TestClient
from api import app

client = TestClient(app)

def test_get_books_initially_list():
    r = client.get('/books')
    assert r.status_code == 200
    assert isinstance(r.json(), list)

def test_add_and_delete_book():
    isbn = "9780140328721"
    r = client.post('/books', json={"isbn": isbn})
    assert r.status_code == 200
    data = r.json()
    assert data["isbn"] == isbn
    # list should include the book
    r2 = client.get('/books')
    assert any(b["isbn"] == isbn for b in r2.json())
    # delete
    r3 = client.delete(f"/books/{isbn}")
    assert r3.status_code == 200
    # deleting again should 404
    r4 = client.delete(f"/books/{isbn}")
    assert r4.status_code == 404
